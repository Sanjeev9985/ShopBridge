﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ShopBridge.WebUI.Models
{
    public class ProductModel
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required(ErrorMessage = "Category field is required")]
        public int CategoryID { get; set; }
        [Required]
        [Range(1.0, double.MaxValue, ErrorMessage = "Please enter correct value")]
        public decimal Price { get; set; }

        public int ProductID { get; set; }
       
        public string CategoryName { get; set; }

      
    }
}