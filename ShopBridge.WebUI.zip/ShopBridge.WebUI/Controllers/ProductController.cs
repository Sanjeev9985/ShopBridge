﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShopBridge.DB.Model;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace ShopBridge.WebUI.Controllers
{
    public class ProductController : Controller
    {
        private ShopBridgeEntities db = new ShopBridgeEntities();
        string Baseurl = "http://localhost:11980/";

        //
        // GET: /Product/

        public ActionResult Index()
        {
            List<ProductModel> Lst_product = new List<ProductModel>();
            using (var client=new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Add("Authorization", "Basic YWJjOmFiYw==");
                //client.DefaultRequestHeaders.Clear();

                //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var Res = client.GetAsync("api/Product/GetProducts");
                Res.Wait();

                var result = Res.Result;

                if (result.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var readTask =  result.Content.ReadAsAsync<List<ProductModel>>();
                    readTask.Wait();
                    //Deserializing the response recieved from web api and storing into the Employee list
                    Lst_product = readTask.Result;//JsonConvert.DeserializeObject<List<Product>>(ProductResp);
                }
                //returning the employee list to view
                return View(Lst_product);
            }
            //return View(db.Products.ToList());
        }

        //
        // GET: /Product/Details/5

        public ActionResult Details(int id = 0)
        {
            ShopBridge.WebUI.Models.ProductModel product = new ShopBridge.WebUI.Models.ProductModel();
            product = GetProduct(id);

            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        //
        // GET: /Product/Create

        public ActionResult Create()
        {
            
            ViewBag.CategoryList = new SelectList(GetCategories(), "CategoryID", "Description");
            return View();
        }

        private IEnumerable<Category> GetCategories()
        {
            List<Category> Lst_category = new List<Category>();
            try
            {
                using (var client=new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders.Add("Authorization", "Basic YWJjOmFiYw==");
                    var Res = client.GetAsync("api/Product/GetCategories");
                    Res.Wait();

                    var result = Res.Result;

                    if (result.IsSuccessStatusCode)
                    {
                         var readTask =  result.Content.ReadAsAsync<List<Category>>();
                        readTask.Wait();

                        Lst_category = readTask.Result;
                        //ViewBag.CategoryList = new SelectList(Lst_category, "CategoryID", "Description");
                        return Lst_category;
                    }

                    
                }

                return Enumerable.Empty<Category>();
            }
            catch (Exception ex)
            {
                
                throw;
            }
        }

        

        //
        // POST: /Product/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                using (var client=new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders.Add("Authorization", "Basic YWJjOmFiYw==");
                    var postTask = client.PostAsJsonAsync<Product>("api/Product/PostProduct", product);
                    postTask.Wait();

                    var result = postTask.Result;

                    if (result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                }
                ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            }
            ViewBag.CategoryList = new SelectList(GetCategories(), "CategoryID", "Description");
            return View(product);
        }

        private ShopBridge.WebUI.Models.ProductModel GetProduct(int id)
        {
            ShopBridge.WebUI.Models.ProductModel product = new ShopBridge.WebUI.Models.ProductModel();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Add("Authorization", "Basic YWJjOmFiYw==");
                var Res = client.GetAsync("api/Product/GetProduct/" + id);
                Res.Wait();

                var result = Res.Result;

                if (result.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var readTask = result.Content.ReadAsAsync<ShopBridge.WebUI.Models.ProductModel>();
                    readTask.Wait();
                    //Deserializing the response recieved from web api and storing into the Employee list
                    product = readTask.Result;//JsonConvert.DeserializeObject<List<Product>>(ProductResp);
                    return product;
                }
            }
            return null;
        }

        //
        // GET: /Product/Edit/5

        public ActionResult Edit(int id = 0)
        {
            ShopBridge.WebUI.Models.ProductModel product = new ShopBridge.WebUI.Models.ProductModel();
            product = GetProduct(id);
            
            if (product == null)
            {
                return HttpNotFound();
            }
            
            ViewBag.CategoryList = new SelectList(GetCategories(), "CategoryID", "Description",product.CategoryID);
            return View(product);
        }

        //
        // POST: /Product/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders.Add("Authorization", "Basic YWJjOmFiYw==");
                    var postTask = client.PutAsJsonAsync<Product>("api/Product/PutProduct/"+product.ProductID, product);
                    postTask.Wait();

                    var result = postTask.Result;

                    if (result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                }
                
            }
            ViewBag.CategoryList = new SelectList(GetCategories(), "CategoryID", "Description", product.CategoryID);
            return View(product);
        }

        //
        // GET: /Product/Delete/5

        public ActionResult Delete(int id = 0)
        {
            ShopBridge.WebUI.Models.ProductModel product = new ShopBridge.WebUI.Models.ProductModel();
            product = GetProduct(id);

            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        //
        // POST: /Product/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Add("Authorization", "Basic YWJjOmFiYw==");
                var postTask = client.DeleteAsync("api/Product/DeleteProduct/"+ id);
                postTask.Wait();

                var result = postTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }
            ShopBridge.WebUI.Models.ProductModel product = new ShopBridge.WebUI.Models.ProductModel();
            product = GetProduct(id);
            return View(product);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}