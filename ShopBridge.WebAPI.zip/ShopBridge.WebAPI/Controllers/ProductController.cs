﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using ShopBridge.DB.Model;
using ShopBridge.WebAPI.Infrastructure.Repository;
using ShopBridge.WebAPI.Infrastructure.Auth;

namespace ShopBridge.WebAPI.Controllers
{
    [BasicAuthentication]
    public class ProductController : ApiController
    {
        //private ShopBridgeEntities db = new ShopBridgeEntities();
        private ProductRepository repository = new ProductRepository();

        // GET api/Product
        public IEnumerable<ProductModel> GetProducts()
        {
            var products = (from a in repository.GetProducts()
                            join b in repository.GetCategories() on a.CategoryID ?? 0 equals b.CategoryID
                            select new ProductModel
                            {
                                ProductID = a.ProductID,
                                CategoryID = a.CategoryID ?? 0,
                                CategoryName = b.Description,
                                Description = a.Description,
                                Name = a.Name,
                                Price = a.Price ?? 0
                            }).ToList();

            return products.AsEnumerable();
        }

        public IEnumerable<Category> GetCategories()
        {
            var Categories = repository.GetCategories();
            return Categories.AsEnumerable();
        }

        //public HttpResponseMessage GetProducts()
        //{
        //    var products = repository.GetProducts();
        //    return Request.CreateResponse(HttpStatusCode.OK, products);
        //}

        // GET api/Product/5
        public ProductModel GetProduct(int id)
        {
            Product product = repository.GetProduct(id);
            if (product == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            var Category = repository.GetCategory(product.CategoryID??0);

            ProductModel model = new ProductModel();
            model.CategoryID = product.CategoryID??0;
            model.CategoryName = Category.Description;
            model.Description = product.Description;
            model.Name = product.Name;
            model.Price = product.Price??0;
            model.ProductID = product.ProductID;

            return model;
        }

        public Category GetCategory(int id)
        {
            Category category = repository.GetCategory(id);
            if (category == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return category;
        }

        // PUT api/Product/5
        [HttpPut]
        public HttpResponseMessage PutProduct(int id, Product product)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != product.ProductID)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            try
            {
                repository.UpdateProduct(id, product);
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Product
        [HttpPost]
        public HttpResponseMessage PostProduct(Product product)
        {
            if (ModelState.IsValid)
            {
                repository.CreateProduct(product);

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, product);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = product.ProductID }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/Product/5
        [HttpDelete]
        public HttpResponseMessage DeleteProduct(int id)
        {

            Product product = null;
            try
            {
                product=repository.DeleteProduct(id);
                if (product == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound);
                }
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, product);
        }

       
    }
}