﻿using ShopBridge.DB.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data;

namespace ShopBridge.WebAPI.Infrastructure.Repository
{
    public class ProductRepository
    {
        private ShopBridgeEntities db = new ShopBridgeEntities();

        public IEnumerable<Product> GetProducts()
        {
            var products = db.Products;
            return products.AsEnumerable();
        }

        public IEnumerable<Category> GetCategories()
        {
            var Categories = db.Categories;
            return Categories.AsEnumerable();
        }

        // GET api/Product/5
        public Product GetProduct(int id)
        {
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return null;
            }

            return product;
        }

        public Category GetCategory(int id)
        {
            Category category = db.Categories.Find(id);
            if (category == null)
            {
                return null;
            }

            return category;
        }

        // PUT api/Product/5
        public void UpdateProduct(int id, Product product)
        {
            db.Entry(product).State = EntityState.Modified;
            db.SaveChanges();
        }

        // POST api/Product
        public void CreateProduct(Product product)
        {
            db.Products.Add(product);
            db.SaveChanges();
        }

        // DELETE api/Product/5
        public Product DeleteProduct(int id)
        {
            
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return null;
            }

            db.Products.Remove(product);
            db.SaveChanges();
            return product;
        }
    }
}