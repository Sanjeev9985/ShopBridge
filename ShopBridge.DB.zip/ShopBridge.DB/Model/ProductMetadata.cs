﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge.DB.Model
{
    //[MetadataType(typeof(ProductMetadata))]
    public partial class Product
    {
    }

    //public class ProductMetadata
    //{
    //    [Required]
    //    public string Name { get; set; }
    //    [Required]
    //    public string Description { get; set; }
    //    [Required(ErrorMessage="Category field is required")]
    //    public Nullable<int> CategoryID { get; set; }
    //    [Required]
    //    [Range(1.0,double.MaxValue,ErrorMessage="Please enter correct value")]
    //    public Nullable<decimal> Price { get; set; }
       
    //}
}
